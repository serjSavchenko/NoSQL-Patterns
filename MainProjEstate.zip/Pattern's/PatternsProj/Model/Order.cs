﻿using System.Collections.Generic;

namespace PatternProj.Model
{
    public class Order
    {
        private readonly List<Estate> products = new List<Estate>();

        private Order()
        {
        }

        public Department sending_department { set; internal get; }
        public string sending_client_id { set; internal get; }
        public PaymentType payment_type { set; internal get; }
        public Department delivery_department { set; internal get; }
        public string delivery_client_email { set; internal get; }

        public Estate[] getProducts => products.ToArray();

        public class Builder
        {
            private readonly Order obj;

            public Builder()
            {
                obj = new Order();
            }

            public Builder setSendingDepartment(Department sending_department)
            {
                obj.sending_department = sending_department;
                return this;
            }

            public Builder setSendingClient(string sending_client_id)
            {
                obj.sending_client_id = sending_client_id;
                return this;
            }

            public Builder setPaymentType(PaymentType payment_type)
            {
                obj.payment_type = payment_type;
                return this;
            }

            public Builder setDeliveryDepartment(Department delivery_department)
            {
                obj.delivery_department = delivery_department;
                return this;
            }

            public Builder setDeliveryClientEmail(string delivery_client_email)
            {
                obj.delivery_client_email = delivery_client_email;
                return this;
            }

            public Builder addProduct(Estate estate)
            {
                obj.products.Add(estate);
                return this;
            }

            public Builder addProducts(ICollection<Estate> products)
            {
                obj.products.AddRange(products);
                return this;
            }

            public Order build()
            {
                return obj;
            }
        }
    }
}