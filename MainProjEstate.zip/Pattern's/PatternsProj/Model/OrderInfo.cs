﻿namespace PatternProj.Model
{
    internal class OrderInfo
    {
        public string cliendSendingFio { get; set; }
        public string clientDelivetyFio { get; set; }
        public string OrderID { get; set; }
        public string Cargo { get; set; }
        public int countCargo { get; set; }
        public string nameOfDepartment { get; set; }
        public string statusName { get; set; }
        public string Date { get; set; }
    }
}