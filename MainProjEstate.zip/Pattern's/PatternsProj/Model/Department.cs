﻿namespace PatternProj.Model
{
    public class Department
    {
        public Department()
        {
        }

        public Department(string id, string name, string city, string openDate)
        {
            Id = id;
            Name = name;
            City = city;
            OpenDate = openDate;
        }

        public string Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string OpenDate { get; set; }
    }
}