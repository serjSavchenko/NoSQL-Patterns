﻿namespace PatternProj.Model
{
    internal class User
    {
        public string id { set; get; }
        public string firstName { set; get; }
        public string lastName { set; get; }
        public string contacts { set; get; }
        public string discount { set; get; }
        public string registration_date { set; get; }
        public string password { set; get; }
        public string gender { set; get; }
    }
}