﻿namespace PatternProj.Model
{
    public class PaymentType
    {
        public PaymentType()
        {
        }

        public PaymentType(string id, string name)
        {
            Id = id;
            Name = name;
        }

        public string Id { get; set; }
        public string Name { get; set; }
    }
}