﻿using System.ComponentModel;
using PatternProj.Momento;

namespace PatternProj.Model
{
    public class Estate : INotifyPropertyChanged
    {
        private readonly Storage storage = new Storage();
        public long Id { get; set; } = -1;
        public string Room { get; set; }
        public float Room_Width { get; set; } = 1;
        public float Room_Height { get; set; } = 1;
        public float Room_Area { get; set; } = 1;
        public float Room_Floor { get; set; } = 1;
        public EstateType Room_Type { get; set; }
        public int Room_Count { get; set; } = 1;

        public event PropertyChangedEventHandler PropertyChanged;

        public void SaveState()
        {
            storage.Save(new EstateMomento(Id, Room, Room_Width, Room_Height, Room_Area, Room_Floor, Room_Type,
                Room_Count));
        }

        public void RestoreState()
        {
            var momento = storage.Restore();
            if (momento != null)
            {
                Id = momento.Id;
                Room = momento.Room;
                Room_Width = momento.Room_Width;
                Room_Height = momento.Room_Height;
                Room_Area = momento.Room_Area;
                Room_Floor = momento.Room_Floor;
                Room_Type = momento.Room_Type;
                Room_Count = momento.Room_Count;
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(null));
            }
        }
    }
}