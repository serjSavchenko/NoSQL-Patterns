﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using PatternProj.AbstractFactory;
using PatternProj.ListenerPattern;
using PatternProj.Model;

namespace PatternProj
{
    /// <summary>
    ///     Логика взаимодействия для CreateOrderWindow.xaml
    /// </summary>
    public partial class CreateOrderWindow : Window
    {
        private readonly ListenerManager mListener = new ListenerManager();
        private readonly ObservableCollection<Estate> mProductList = new ObservableCollection<Estate>();

        private readonly IAbstractFactory abstractFactory = FactoryProvider.GetFactory();

        private List<Department> departments;

        private List<PaymentType> paymentTypes;

        private List<EstateType> productTypes;

        public CreateOrderWindow(IListener listener)
        {
            InitializeComponent();
            mListener.addListener(listener);
            productsDataGrid.CellEditEnding += ProductsDataGrid_CellEditEnding;
            setDataGridSource();
            productsDataGrid.ItemsSource = mProductList;
            //productsDataGrid.RowEditEnding += ProductsDataGrid_RowEditEnding;
            KeyDown += CreateOrderWindow_KeyDown;
        }

        private async void setDataGridSource()
        {
            await Task.Run(() =>
            {
                productTypes = abstractFactory.GetProductTypeDao().GetEstateTypes();
                departments = abstractFactory.GetDaoDepartment().GetDepartments();
                paymentTypes = abstractFactory.GetPaymentTypeDao().GetPaymentTypes();
            });
            Delivery_department.ItemsSource = Sending_department.ItemsSource = departments;
            Payment_type.ItemsSource = paymentTypes;
            ((DataGridComboBoxColumn) productsDataGrid.Columns[5]).ItemsSource = productTypes;
        }

        private void CreateOrderWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyboardDevice.Modifiers == ModifierKeys.Control && e.Key == Key.Z)
                mProductList[productsDataGrid.SelectedIndex].RestoreState();
        }

        private void ProductsDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit) mProductList[productsDataGrid.SelectedIndex].SaveState();
        }

        private void addProductButton_Click(object sender, RoutedEventArgs e)
        {
            mProductList.Add(new Estate());
        }

        private void DataGridComboBoxColumn_SourceUpdated(object sender, SelectionChangedEventArgs e)
        {
            mProductList[productsDataGrid.SelectedIndex].Room_Type = productTypes[((ComboBox) sender).SelectedIndex];
        }

        private async void createOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (mProductList.Count != 0 && Sending_department.SelectedIndex != Delivery_department.SelectedIndex)
            {
                var result = await abstractFactory.GetOrderDao().CreateOrder(new Order.Builder()
                    .setSendingDepartment(departments[Sending_department.SelectedIndex])
                    .setSendingClient(FactoryProvider.User.id)
                    .setPaymentType(paymentTypes[Payment_type.SelectedIndex])
                    .setDeliveryDepartment(departments[Delivery_department.SelectedIndex])
                    .setDeliveryClientEmail(Delivery_client.Text)
                    .addProducts(mProductList.ToArray())
                    .build());
                if (result)
                {
                    mListener.notifyLiteners();
                    Close();
                }
            }
        }

        private void removeProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (mProductList.Count != 0 && productsDataGrid.SelectedItem != null)
                mProductList.RemoveAt(productsDataGrid.SelectedIndex);
        }
    }
}