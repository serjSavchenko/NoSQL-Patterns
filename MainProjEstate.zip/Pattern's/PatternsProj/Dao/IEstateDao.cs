﻿using PatternProj.Model;

namespace PatternProj.Dao
{
    internal interface IEstateDao
    {
        void setEstate(Estate[] products);
    }
}