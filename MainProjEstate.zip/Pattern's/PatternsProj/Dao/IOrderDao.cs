﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PatternProj.Model;

namespace PatternProj.Dao
{
    internal interface IOrderDao
    {
        List<OrderInfo> GetOrderInfos(string clientId);
        Task<bool> CreateOrder(Order order);
    }
}