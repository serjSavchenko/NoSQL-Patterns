﻿using System.Collections.Generic;
using PatternProj.Model;

namespace PatternProj.Dao
{
    public interface IPaymentTypeDao
    {
        List<PaymentType> GetPaymentTypes();
    }
}