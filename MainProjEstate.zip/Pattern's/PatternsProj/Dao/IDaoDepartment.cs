﻿using System.Collections.Generic;
using PatternProj.Model;

namespace PatternProj.Dao
{
    public interface IDaoDepartment
    {
        List<Department> GetDepartments();
    }
}