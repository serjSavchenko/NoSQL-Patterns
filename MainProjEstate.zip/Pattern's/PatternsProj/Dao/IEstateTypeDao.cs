﻿using System.Collections.Generic;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    internal interface IEstateTypeDao
    {
        List<EstateType> GetEstateTypes();
    }
}