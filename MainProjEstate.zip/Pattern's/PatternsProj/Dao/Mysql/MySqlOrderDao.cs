﻿using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using PatternProj.AbstractFactory;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    internal class MySqlOrderDao : IOrderDao
    {
        private readonly MySqlConnection mConnection;

        public MySqlOrderDao(MySqlConnection connection)
        {
            mConnection = connection;
        }

        public List<OrderInfo> GetOrderInfos(string clientId)
        {
            var list = new List<OrderInfo>();
            var command = mConnection.CreateCommand();
            command.CommandText = $"call big_data_database.Hruapkin_getInfoAboutOrders({clientId})";
            var reader = command.ExecuteReader();
            while (reader.Read())
                list.Add(new OrderInfo
                {
                    cliendSendingFio = reader.GetString("Firstname Lastname Sending"),
                    clientDelivetyFio = reader.GetString("Firstname Lastname Delivery"),
                    OrderID = reader.GetInt32("OrderID").ToString(),
                    Cargo = reader.GetString("Room"),
                    countCargo = reader.GetInt32("count"),
                    nameOfDepartment = reader.GetString("name_of_department"),
                    statusName = reader.GetString("name"),
                    Date = reader.GetString("Order_date")
                });
            reader.Close();
            return list;
        }

        public async Task<bool> CreateOrder(Order order)
        {
            return await Task.Run(() =>
            {
                var command = mConnection.CreateCommand();
                command.Transaction = mConnection.BeginTransaction();
                command.CommandText = $"select big_data_database.Hryapkin_CreateOrder({order.sending_department.Id}," +
                                      $"{order.sending_client_id},{order.payment_type.Id},{order.delivery_department.Id},'{order.delivery_client_email}')";
                var order_id = (int) command.ExecuteScalar();
                var result = order_id >= 0;
                if (result)
                {
                    FactoryProvider.GetFactory().GetProductDao().setEstate(order.getProducts);
                    var builder =
                        new StringBuilder("insert into big_data_database.cart (order_id,product,count) values ");
                    foreach (var product in order.getProducts)
                        builder.Append($"({order_id},{product.Id},{product.Room_Count}),");
                    builder.Remove(builder.Length - 1, 1);
                    command.CommandText = builder.ToString();
                    command.ExecuteNonQuery();
                }

                command.Transaction.Commit();
                command.Transaction.Dispose();
                return result;
            });
        }
    }
}