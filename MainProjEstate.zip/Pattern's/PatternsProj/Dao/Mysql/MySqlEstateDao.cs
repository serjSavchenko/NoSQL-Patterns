﻿using MySql.Data.MySqlClient;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    internal class MySqlEstateDao : IEstateDao
    {
        private readonly MySqlConnection mConnection;

        public MySqlEstateDao(MySqlConnection connection)
        {
            mConnection = connection;
        }

        public void setEstate(Estate[] products)
        {
            var command = mConnection.CreateCommand();
            for (var i = 0; i < products.Length; i++)
            {
                command.CommandText = "insert into big_data_database.product " +
                                      "(Room,Room_Width,Room_Height,Room_Area,Room_Floor,Room_Type,TEST_TEXT)" +
                                      $"values('{products[i].Room}',{products[i].Room_Width},{products[i].Room_Height},{products[i].Room_Area},{products[i].Room_Floor},{products[i].Room_Type.Id},'d')";
                command.ExecuteScalar();
                products[i].Id = command.LastInsertedId;
            }
        }
    }
}