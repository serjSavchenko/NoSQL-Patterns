﻿using System.Collections.Generic;
using MySql.Data.MySqlClient;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    internal class MySqlDepartmentDao : IDaoDepartment
    {
        private readonly MySqlConnection mConnection;

        public MySqlDepartmentDao(MySqlConnection connection)
        {
            mConnection = connection;
        }

        public List<Department> GetDepartments()
        {
            var list = new List<Department>();
            var command = mConnection.CreateCommand();
            command.CommandText = "SELECT * FROM big_data_database.department";
            var reader = command.ExecuteReader();
            while (reader.Read())
                list.Add(new Department
                {
                    Id = reader.GetString("id_dep"),
                    Name = reader.GetString("name_of_department"),
                    City = reader.GetString("city"),
                    OpenDate = reader.GetString("date_of_open")
                });
            reader.Close();
            return list;
        }
    }
}