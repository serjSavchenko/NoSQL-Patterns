﻿using System.Collections.Generic;
using MySql.Data.MySqlClient;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    public class MySqlPaymentTypeDao : IPaymentTypeDao
    {
        private readonly MySqlConnection mConnection;

        public MySqlPaymentTypeDao(MySqlConnection connection)
        {
            mConnection = connection;
        }

        public List<PaymentType> GetPaymentTypes()
        {
            var list = new List<PaymentType>();
            var command = mConnection.CreateCommand();
            command.CommandText = "SELECT * FROM big_data_database.payment_type";
            var reader = command.ExecuteReader();
            while (reader.Read())
                list.Add(new PaymentType
                {
                    Id = reader.GetString("payment_id"),
                    Name = reader.GetString("ptype")
                });
            reader.Close();
            return list;
        }
    }
}