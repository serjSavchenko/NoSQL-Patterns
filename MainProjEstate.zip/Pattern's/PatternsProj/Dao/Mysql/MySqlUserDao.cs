﻿using System;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using PatternProj.AbstractFactory;
using PatternProj.Model;

namespace PatternProj.Dao
{
    internal class MySqlUserDao : IUserDao
    {
        private readonly MySqlConnection mConnection;

        public MySqlUserDao(MySqlConnection connection)
        {
            mConnection = connection;
        }

        public async Task<User> checkUserAsync(string login, string password)
        {
            User user = null;
            var command = mConnection.CreateCommand();
            command.CommandText =
                "SELECT clients_id, firstName,lastName,contacts,`discount_%`,registration_date,`password`,gender_name " +
                "FROM big_data_database.clients cl, big_data_database.gender gn " +
                $"where cl.gender_id = gn.id and `password` = '{password}' and contacts = '{login}'";
            await Task.Run(() =>
            {
                var reader = command.ExecuteReader();
                while (reader.Read())
                    user = new User
                    {
                        id = reader.GetInt32("clients_id").ToString(),
                        firstName = reader.GetString("firstName"),
                        lastName = reader.GetString("lastName"),
                        discount = reader.GetFloat("discount_%").ToString(),
                        contacts = reader.GetString("contacts"),
                        registration_date = reader.GetString("registration_date"),
                        password = reader.GetString("password"),
                        gender = reader.GetString("gender_name")
                    };
                reader.Close();
            });
            return user;
        }

        public User checkUserByEmail(string email)
        {
            throw new NotImplementedException();
        }

        public bool registrateNewUser(string firstName, string lastName, string contacts, string password, int genderId)
        {
            var result = true;
            var command = mConnection.CreateCommand();
            //$"call big_data_database.Hryapkin_registrateNewUser('{firstName}','{lastName}','{contacts}','{password}',{genderId});"
            command.CommandText =
                $"call big_data_database.Hryapkin_registrateNewUser('{firstName}','{lastName}','{contacts}','{password}',{genderId});";
            try
            {
                command.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                result = false;
            }

            return result;
        }

        public void updateUserInfo(User user)
        {
            var command = mConnection.CreateCommand();
            command.CommandText = "update big_data_database.clients " +
                                  $"set firstName ='{user.firstName}' ,lastName = '{user.lastName}',password = '{user.password}' where clients_id ={FactoryProvider.User.id}";
            command.ExecuteNonQuery();
        }
    }
}