﻿using System.Collections.Generic;
using MySql.Data.MySqlClient;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    internal class MysqlEstateTypeDao : IEstateTypeDao
    {
        private readonly MySqlConnection mConnection;

        public MysqlEstateTypeDao(MySqlConnection connection)
        {
            mConnection = connection;
        }

        public List<EstateType> GetEstateTypes()
        {
            var list = new List<EstateType>();
            var command = mConnection.CreateCommand();
            command.CommandText = "SELECT * FROM big_data_database.order_type;";
            var reader = command.ExecuteReader();
            while (reader.Read())
                list.Add(new EstateType
                {
                    Id = reader.GetInt32("Order_TypeID").ToString(),
                    Name = reader.GetString("Ordr_Type"),
                    Description = reader.GetString("Ordr_Type_Decription")
                });
            reader.Close();
            return list;
        }
    }
}