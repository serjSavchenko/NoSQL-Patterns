﻿using MongoDB.Driver;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    internal class MongoEstateDao : IEstateDao
    {
        private IMongoDatabase mDatabase;

        public MongoEstateDao(IMongoDatabase database)
        {
            mDatabase = database;
        }

        public void setEstate(Estate[] products)
        {
        }
    }
}