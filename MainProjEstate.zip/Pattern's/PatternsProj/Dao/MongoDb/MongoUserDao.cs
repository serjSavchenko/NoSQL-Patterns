﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using PatternProj.AbstractFactory;
using PatternProj.Model;

namespace PatternProj.Dao
{
    internal class MongoUserDao : IUserDao
    {
        private readonly IMongoCollection<BsonDocument> collection;
        private readonly IMongoDatabase mDatabase;

        public MongoUserDao(IMongoDatabase database)
        {
            mDatabase = database;
            collection = mDatabase.GetCollection<BsonDocument>("clients");
        }

        public async Task<User> checkUserAsync(string login, string password)
        {
            return returnUserFromListIfExist(await Task.Run(() =>
                collection.Find(new BsonDocument("$and", new BsonArray
                {
                    new BsonDocument("contacts", login),
                    new BsonDocument("password", password)
                })).ToList()));
        }

        public bool registrateNewUser(string firstName, string lastName, string contacts, string password, int genderId)
        {
            if (collection.Find(new BsonDocument("contacts", contacts)).ToList().Count != 0) return false;

            collection.InsertOne(new BsonDocument
            {
                {"firstName", firstName},
                {"lastName", lastName},
                {"contacts", contacts},
                {"discount_%", "0"},
                {"registration_date", DateTime.Now},
                {"password ", password},
                {"gender_name", genderId == 1 ? "Мужской" : "Женский"}
            });
            return true;
        }

        public void updateUserInfo(User user)
        {
            collection.UpdateMany(
                Builders<BsonDocument>.Filter.Eq("_id", new BsonObjectId(new ObjectId(FactoryProvider.User.id))),
                Builders<BsonDocument>.Update
                    .Set("firstName", user.firstName)
                    .Set("lastName", user.lastName)
                    .Set("password", user.password));
        }

        public User checkUserByEmail(string email)
        {
            return returnUserFromListIfExist(collection.Find(new BsonDocument("contacts", email)).ToList());
        }

        private User returnUserFromListIfExist(List<BsonDocument> list)
        {
            User user = null;
            if (list.Count != 0)
                user = new User
                {
                    id = list[0].GetValue("_id").AsObjectId.ToString(),
                    firstName = list[0].GetValue("firstName").AsString,
                    lastName = list[0].GetValue("lastName").AsString,
                    discount = list[0].GetValue("discount_%").AsString,
                    contacts = list[0].GetValue("contacts").AsString,
                    registration_date = list[0].GetValue("registration_date").AsString,
                    password = list[0].GetValue("password").AsString,
                    gender = list[0].GetValue("gender_name").AsString
                };
            return user;
        }
    }
}