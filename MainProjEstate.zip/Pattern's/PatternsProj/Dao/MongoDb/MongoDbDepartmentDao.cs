﻿using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Driver;
using PatternProj.Model;

namespace PatternProj.Dao.MongoDb
{
    public class MongoDbDepartmentDao : IDaoDepartment
    {
        private readonly IMongoCollection<BsonDocument> collection;
        private readonly IMongoDatabase mDatabase;

        public MongoDbDepartmentDao(IMongoDatabase database)
        {
            mDatabase = database;
            collection = mDatabase.GetCollection<BsonDocument>("Department");
        }

        public List<Department> GetDepartments()
        {
            var list = new List<Department>();
            foreach (var doc in collection.Find(new BsonDocument()).ToList())
                list.Add(new Department
                {
                    Id = doc.GetValue("_id").AsObjectId.ToString(),
                    Name = doc.GetValue("name_of_department").AsString,
                    City = doc.GetValue("city").AsString,
                    OpenDate = doc.GetValue("date_of_open").AsString
                });
            return list;
        }
    }
}