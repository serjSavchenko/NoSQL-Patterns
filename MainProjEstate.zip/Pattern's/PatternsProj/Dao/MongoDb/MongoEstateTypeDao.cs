﻿using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Driver;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    internal class MongoEstateTypeDao : IEstateTypeDao
    {
        private readonly IMongoCollection<BsonDocument> collection;
        private readonly IMongoDatabase mDatabase;

        public MongoEstateTypeDao(IMongoDatabase database)
        {
            mDatabase = database;
            collection = mDatabase.GetCollection<BsonDocument>("cargo_type");
        }

        public List<EstateType> GetEstateTypes()
        {
            var list = new List<EstateType>();
            foreach (var doc in collection.Find(new BsonDocument()).ToList())
                list.Add(new EstateType
                {
                    Id = doc.GetValue("_id").AsObjectId.ToString(),
                    Name = doc.GetValue("Ordr_Type").AsString,
                    Description = doc.GetValue("Ordr_Type_Decription").AsString
                });
            return list;
        }
    }
}