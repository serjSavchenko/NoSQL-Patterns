﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using PatternProj.AbstractFactory;
using PatternProj.Model;

namespace PatternProj.Dao.Mysql
{
    internal class MongoOrderDao : IOrderDao
    {
        private readonly IMongoCollection<BsonDocument> collection;
        private readonly IMongoDatabase mDatabase;

        public MongoOrderDao(IMongoDatabase database)
        {
            mDatabase = database;
            collection = mDatabase.GetCollection<BsonDocument>("orders");
        }

        public List<OrderInfo> GetOrderInfos(string clientId)
        {
            var list = new List<OrderInfo>();
            foreach (var document in collection
                .Find(new BsonDocument("sending_client._id", new BsonObjectId(new ObjectId(clientId)))).ToList())
            foreach (var product in document.GetValue("produsts").AsBsonArray)
                list.Add(new OrderInfo
                {
                    cliendSendingFio =
                        document.GetValue("sending_client").AsBsonDocument.GetValue("lastName").AsString + " " +
                        document.GetValue("sending_client").AsBsonDocument.GetValue("firstName").AsString,
                    clientDelivetyFio =
                        document.GetValue("delivery_client").AsBsonDocument.GetValue("lastName").AsString + " " +
                        document.GetValue("delivery_client").AsBsonDocument.GetValue("firstName").AsString,
                    OrderID = document.GetValue("_id").AsObjectId.ToString(),
                    Cargo = product.AsBsonDocument.GetValue("Room").AsString,
                    countCargo = product.AsBsonDocument.GetValue("Room_Count").AsInt32,
                    nameOfDepartment = document.GetValue("delivery_department").AsBsonDocument
                        .GetValue("name_of_department").AsString,
                    statusName = document.GetValue("status").AsString,
                    Date = document.GetValue("Order_date").AsString
                });
            return list;
        }

        public async Task<bool> CreateOrder(Order order)
        {
            return await Task.Run(() =>
            {
                var deliveryClient = FactoryProvider.GetFactory().GetUserDao()
                    .checkUserByEmail(order.delivery_client_email);
                if (deliveryClient != null)
                {
                    var sendingClient = FactoryProvider.User;
                    var bsonArray = new BsonArray();
                    foreach (var product in order.getProducts)
                        bsonArray.Add(new BsonDocument
                        {
                            {"Room", product.Room},
                            {"Room_Width", product.Room_Width},
                            {"Room_Height", product.Room_Height},
                            {"Room_Area", product.Room_Area},
                            {"Room_Floor", product.Room_Floor},
                            {
                                "Room_Type", new BsonDocument
                                {
                                    {"_id", new BsonObjectId(new ObjectId(product.Room_Type.Id))},
                                    {"Name", product.Room_Type.Name},
                                    {"Description", product.Room_Type.Description}
                                }
                            },
                            {"Room_Count", product.Room_Count}
                        });
                    collection.InsertOne(new BsonDocument
                    {
                        {"Order_date", DateTime.Now.ToString()},
                        {
                            "sending_department", new BsonDocument
                            {
                                {"_id", new BsonObjectId(new ObjectId(order.sending_department.Id))},
                                {"name_of_department", order.sending_department.Name},
                                {"city", order.sending_department.City},
                                {"date_of_open", order.sending_department.OpenDate}
                            }
                        },
                        {
                            "sending_client", new BsonDocument
                            {
                                {"_id", new BsonObjectId(new ObjectId(sendingClient.id))},
                                {"firstName", sendingClient.firstName},
                                {"lastName", sendingClient.lastName},
                                {"contacts", sendingClient.contacts},
                                {"discount_%", sendingClient.discount},
                                {"registration_date", sendingClient.registration_date},
                                {"password ", sendingClient.password},
                                {"gender_name", sendingClient.gender}
                            }
                        },
                        {
                            "payment_type", new BsonDocument
                            {
                                {"_id", new BsonObjectId(new ObjectId(order.payment_type.Id))},
                                {"name", order.payment_type.Name}
                            }
                        },
                        {
                            "delivery_department", new BsonDocument
                            {
                                {"_id", new BsonObjectId(new ObjectId(order.delivery_department.Id))},
                                {"name_of_department", order.delivery_department.Name},
                                {"city", order.delivery_department.City},
                                {"date_of_open", order.delivery_department.OpenDate}
                            }
                        },
                        {"status", "подтвержден"},
                        {
                            "delivery_client", new BsonDocument
                            {
                                {"_id", new BsonObjectId(new ObjectId(deliveryClient.id))},
                                {"firstName", deliveryClient.firstName},
                                {"lastName", deliveryClient.lastName},
                                {"contacts", deliveryClient.contacts},
                                {"discount_%", deliveryClient.discount},
                                {"registration_date", deliveryClient.registration_date},
                                {"password ", deliveryClient.password},
                                {"gender_name", deliveryClient.gender}
                            }
                        },
                        {"produsts", bsonArray}
                    });
                    return true;
                }

                return false;
            });
        }
    }
}