﻿using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Driver;
using PatternProj.Model;

namespace PatternProj.Dao.MongoDb
{
    public class MongoDbPaymentTypeDao : IPaymentTypeDao
    {
        private readonly IMongoCollection<BsonDocument> collection;
        private readonly IMongoDatabase mDatabase;

        public MongoDbPaymentTypeDao(IMongoDatabase database)
        {
            mDatabase = database;
            collection = mDatabase.GetCollection<BsonDocument>("PaymentType");
        }

        public List<PaymentType> GetPaymentTypes()
        {
            var list = new List<PaymentType>();
            foreach (var doc in collection.Find(new BsonDocument()).ToList())
                list.Add(new PaymentType
                {
                    Id = doc.GetValue("_id").AsObjectId.ToString(),
                    Name = doc.GetValue("ptype").AsString
                });
            return list;
        }
    }
}