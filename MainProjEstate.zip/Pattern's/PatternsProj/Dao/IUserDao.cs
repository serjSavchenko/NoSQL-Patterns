﻿using System.Threading.Tasks;
using PatternProj.Model;

namespace PatternProj.Dao
{
    internal interface IUserDao
    {
        Task<User> checkUserAsync(string login, string password);
        bool registrateNewUser(string firstName, string lastName, string contacts, string password, int genderId);
        void updateUserInfo(User user);
        User checkUserByEmail(string email);
    }
}