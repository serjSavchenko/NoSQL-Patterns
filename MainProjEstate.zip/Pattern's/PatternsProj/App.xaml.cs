﻿using System;
using System.Windows;
using PatternProj.AbstractFactory;

namespace PatternProj
{
    /// <summary>
    ///     Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnActivated(EventArgs e)
        {
            FactoryProvider.GetFactory().openConnection();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            FactoryProvider.GetFactory().closeConnection();
        }
    }
}