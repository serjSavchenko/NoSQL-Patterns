﻿using PatternProj.Model;

namespace PatternProj.AbstractFactory
{
    internal class FactoryProvider
    {
        private static IAbstractFactory factory;

        public static User User { get; set; }

        public static IAbstractFactory GetFactory()
        {
            if (factory == null) factory = new MongoDbFactory();
            return factory;
        }
    }
}