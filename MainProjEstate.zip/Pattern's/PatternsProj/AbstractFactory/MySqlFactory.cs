﻿using System.Data;
using MySql.Data.MySqlClient;
using PatternProj.Dao;
using PatternProj.Dao.Mysql;

namespace PatternProj.AbstractFactory
{
    internal class MySqlFactory : IAbstractFactory
    {
        private MySqlConnection connection;

        private MySqlDepartmentDao mMySqlDepartmentDao;

        private MySqlEstateDao mMySqlEstateDao;

        private MysqlEstateTypeDao mMySqlEstateTypeDao;

        private MySqlOrderDao mMySqlOrderDao;

        private MySqlPaymentTypeDao mMySqlPaymentTypeDao;
        private MySqlUserDao mMySqlUserDao;

        public void openConnection()
        {
            connection = new MySqlConnection("**"); //connection string
            connection.OpenAsync();
        }

        public void closeConnection()
        {
            if (connection != null && connection.State == ConnectionState.Open) connection.CloseAsync();
        }

        public IUserDao GetUserDao()
        {
            if (mMySqlUserDao == null) mMySqlUserDao = new MySqlUserDao(connection);
            return mMySqlUserDao;
        }

        public IOrderDao GetOrderDao()
        {
            if (mMySqlOrderDao == null) mMySqlOrderDao = new MySqlOrderDao(connection);
            return mMySqlOrderDao;
        }

        public IEstateTypeDao GetProductTypeDao()
        {
            if (mMySqlEstateTypeDao == null) mMySqlEstateTypeDao = new MysqlEstateTypeDao(connection);
            return mMySqlEstateTypeDao;
        }

        public IEstateDao GetProductDao()
        {
            if (mMySqlEstateDao == null) mMySqlEstateDao = new MySqlEstateDao(connection);
            return mMySqlEstateDao;
        }

        public IDaoDepartment GetDaoDepartment()
        {
            if (mMySqlDepartmentDao == null) mMySqlDepartmentDao = new MySqlDepartmentDao(connection);
            return mMySqlDepartmentDao;
        }

        public IPaymentTypeDao GetPaymentTypeDao()
        {
            if (mMySqlPaymentTypeDao == null) mMySqlPaymentTypeDao = new MySqlPaymentTypeDao(connection);
            return mMySqlPaymentTypeDao;
        }
    }
}