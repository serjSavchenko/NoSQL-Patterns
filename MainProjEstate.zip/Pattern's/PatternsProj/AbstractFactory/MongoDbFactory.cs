﻿using MongoDB.Driver;
using PatternProj.Dao;
using PatternProj.Dao.MongoDb;
using PatternProj.Dao.Mysql;

namespace PatternProj.AbstractFactory
{
    internal class MongoDbFactory : IAbstractFactory
    {
        private IMongoDatabase database;

        private MongoDbDepartmentDao mMongoDbDepartmentDao;

        private MongoDbPaymentTypeDao mMongoDbPaymentTypeDao;

        private MongoEstateDao mMySqlEstateDao;

        private MongoEstateTypeDao mMySqlEstateTypeDao;

        private MongoOrderDao mMySqlOrderDao;
        private MongoUserDao mMySqlUserDao;

        public void openConnection()
        {
            var connectionString = "**"; //connection string
            database = new MongoClient(connectionString)
                .GetDatabase("estate_agency");
        }

        public void closeConnection()
        {
            database.Client.Cluster.Dispose();
        }

        public IUserDao GetUserDao()
        {
            if (mMySqlUserDao == null) mMySqlUserDao = new MongoUserDao(database);
            return mMySqlUserDao;
        }

        public IOrderDao GetOrderDao()
        {
            if (mMySqlOrderDao == null) mMySqlOrderDao = new MongoOrderDao(database);
            return mMySqlOrderDao;
        }

        public IEstateTypeDao GetProductTypeDao()
        {
            if (mMySqlEstateTypeDao == null) mMySqlEstateTypeDao = new MongoEstateTypeDao(database);
            return mMySqlEstateTypeDao;
        }

        public IEstateDao GetProductDao()
        {
            if (mMySqlEstateDao == null) mMySqlEstateDao = new MongoEstateDao(database);
            return mMySqlEstateDao;
        }

        public IDaoDepartment GetDaoDepartment()
        {
            if (mMongoDbDepartmentDao == null) mMongoDbDepartmentDao = new MongoDbDepartmentDao(database);
            return mMongoDbDepartmentDao;
        }

        public IPaymentTypeDao GetPaymentTypeDao()
        {
            if (mMongoDbPaymentTypeDao == null) mMongoDbPaymentTypeDao = new MongoDbPaymentTypeDao(database);
            return mMongoDbPaymentTypeDao;
        }
    }
}