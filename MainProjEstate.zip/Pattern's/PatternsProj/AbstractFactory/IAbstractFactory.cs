﻿using PatternProj.Dao;
using PatternProj.Dao.Mysql;

namespace PatternProj.AbstractFactory
{
    internal interface IAbstractFactory
    {
        IUserDao GetUserDao();
        IOrderDao GetOrderDao();
        IEstateTypeDao GetProductTypeDao();
        IEstateDao GetProductDao();
        IDaoDepartment GetDaoDepartment();
        IPaymentTypeDao GetPaymentTypeDao();
        void openConnection();
        void closeConnection();
    }
}