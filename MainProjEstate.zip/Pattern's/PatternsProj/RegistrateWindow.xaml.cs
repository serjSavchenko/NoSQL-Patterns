﻿using System.Windows;
using PatternProj.AbstractFactory;

namespace PatternProj
{
    /// <summary>
    ///     Логика взаимодействия для RegistrateWindow.xaml
    /// </summary>
    public partial class RegistrateWindow : Window
    {
        private readonly IAbstractFactory abstractFactory = FactoryProvider.GetFactory();

        public RegistrateWindow()
        {
            InitializeComponent();
        }

        private void registrateButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(firstNameTextBox.Text)
                && !string.IsNullOrWhiteSpace(lastNameTextBox.Text)
                && !string.IsNullOrWhiteSpace(emailTextBox.Text)
                && !string.IsNullOrWhiteSpace(passwordTextBox.Password)
                && !string.IsNullOrWhiteSpace(passwordConfirmationTextBox.Password))
            {
                if (passwordTextBox.Password == passwordConfirmationTextBox.Password)
                {
                    var result = abstractFactory.GetUserDao().registrateNewUser(firstNameTextBox.Text,
                        lastNameTextBox.Text, emailTextBox.Text, passwordTextBox.Password,
                        genderComboBox.SelectedIndex + 1);
                    if (result)
                    {
                        MessageBox.Show("Registartion succes", "Ok", MessageBoxButton.OK, MessageBoxImage.Information);
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("A user with this mail already exists!", "Error", MessageBoxButton.OK,
                            MessageBoxImage.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Passwords must be the same!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}