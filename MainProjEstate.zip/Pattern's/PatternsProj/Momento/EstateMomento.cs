﻿using PatternProj.Model;

namespace PatternProj.Momento
{
    public class EstateMomento
    {
        public EstateMomento(long id, string room, float roomWidth, float roomHeight, float roomArea,
            float roomFloor, EstateType roomType, int roomCount)
        {
            Id = id;
            Room = room;
            Room_Width = roomWidth;
            Room_Height = roomHeight;
            Room_Area = roomArea;
            Room_Floor = roomFloor;
            Room_Type = roomType;
            Room_Count = roomCount;
        }

        public long Id { get; }
        public string Room { get; }
        public float Room_Width { get; }
        public float Room_Height { get; }
        public float Room_Area { get; }
        public float Room_Floor { get; }
        public EstateType Room_Type { get; }
        public int Room_Count { get; }
    }
}