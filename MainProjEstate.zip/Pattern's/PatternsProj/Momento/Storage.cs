﻿using System.Collections.Generic;

namespace PatternProj.Momento
{
    public class Storage
    {
        private readonly Stack<EstateMomento> momentos = new Stack<EstateMomento>();

        public void Save(EstateMomento estateMomento)
        {
            momentos.Push(estateMomento);
        }

        public EstateMomento Restore()
        {
            if (momentos.Count != 0)
                return momentos.Pop();
            return null;
        }
    }
}