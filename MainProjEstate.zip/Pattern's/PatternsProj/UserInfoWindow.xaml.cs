﻿using System.Threading.Tasks;
using System.Windows;
using PatternProj.AbstractFactory;
using PatternProj.Model;

namespace PatternProj
{
    /// <summary>
    ///     Логика взаимодействия для UserInfoWindow.xaml
    /// </summary>
    public partial class UserInfoWindow : Window
    {
        private readonly IAbstractFactory abstractFactory = FactoryProvider.GetFactory();

        private readonly User user;

        public UserInfoWindow()
        {
            InitializeComponent();
            user = FactoryProvider.User;
            Firstname_TextBox.Text = user.firstName;
            Lastname_TextBox.Text = user.lastName;
            Email_TextBlock.Text = user.contacts;
            Discount_TextBlock.Text = user.discount;
            Registration_date_TextBox.Text = user.registration_date;
            Password_PasswordBox.Password = user.password;
            Gender_TextBox.Text = user.gender;
        }

        private void Ok_Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Update_Button_Click(object sender, RoutedEventArgs e)
        {
            user.firstName = Firstname_TextBox.Text;
            user.lastName = Lastname_TextBox.Text;
            user.password = Password_PasswordBox.Password;
            Task.Run(() => { abstractFactory.GetUserDao().updateUserInfo(user); });
            Close();
        }

        private void Firstname_TextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {

        }
    }
}