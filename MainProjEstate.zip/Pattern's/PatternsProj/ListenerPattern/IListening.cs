﻿namespace PatternProj.ListenerPattern
{
    public interface IListening
    {
        void addListener(IListener listener);
        void removeListener(IListener listener);
        void notifyLiteners();
    }
}