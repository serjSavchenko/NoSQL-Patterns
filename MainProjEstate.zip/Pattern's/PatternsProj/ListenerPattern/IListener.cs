﻿namespace PatternProj.ListenerPattern
{
    public interface IListener
    {
        void Update();
    }
}