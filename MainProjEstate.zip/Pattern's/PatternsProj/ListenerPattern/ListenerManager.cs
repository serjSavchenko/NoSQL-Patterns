﻿using System.Collections.Generic;

namespace PatternProj.ListenerPattern
{
    public class ListenerManager : IListening
    {
        private readonly List<IListener> listeners = new List<IListener>();

        public void addListener(IListener listener)
        {
            listeners.Add(listener);
        }

        public void removeListener(IListener listener)
        {
            listeners.Remove(listener);
        }

        public void notifyLiteners()
        {
            foreach (var listener in listeners) listener.Update();
        }
    }
}