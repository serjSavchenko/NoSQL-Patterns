﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using PatternProj.AbstractFactory;
using PatternProj.ListenerPattern;
using PatternProj.Model;

namespace PatternProj
{
    /// <summary>
    ///     Логика взаимодействия для OrdersWindow.xaml
    /// </summary>
    public partial class OrdersWindow : Window, IListener
    {
        private readonly IAbstractFactory abstractFactory = FactoryProvider.GetFactory();
        private readonly ObservableCollection<OrderInfo> mOrderInfos = new ObservableCollection<OrderInfo>();

        public OrdersWindow()
        {
            InitializeComponent();
            orderInfoDataGrid.ItemsSource = mOrderInfos;
            reFillOrders();
        }

        public void Update()
        {
            MessageBox.Show("Order created succesfully");
            reFillOrders();
        }

        private async void reFillOrders()
        {
            List<OrderInfo> list = null;
            await Task.Run(() => { list = abstractFactory.GetOrderDao().GetOrderInfos(FactoryProvider.User.id); });
            mOrderInfos.Clear();
            foreach (var orderInfo in list) mOrderInfos.Add(orderInfo);
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            new CreateOrderWindow(this).ShowDialog();
        }

        private void GetUserInfo_Click(object sender, RoutedEventArgs e)
        {
            new UserInfoWindow().ShowDialog();
        }
    }
}