﻿using System.Windows;
using PatternProj.AbstractFactory;

namespace PatternProj
{
    public partial class MainWindow : Window
    {
        private readonly IAbstractFactory abstractFactory = FactoryProvider.GetFactory();

        public MainWindow()
        {
            InitializeComponent();
        }

        private bool isFiledsPermissible()
        {
            return !string.IsNullOrWhiteSpace(loginTextBox.Text) &&
                   !string.IsNullOrWhiteSpace(passwordTextBox.Password);
        }

        private async void onSignInButtonClick(object sender, RoutedEventArgs e)
        {
            if (isFiledsPermissible())
            {
                var user = await abstractFactory.GetUserDao()
                    .checkUserAsync(loginTextBox.Text, passwordTextBox.Password);
                if (user == null)
                {
                    MessageBox.Show("Login or password is not correct", "Error", MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
                else
                {
                    FactoryProvider.User = user;
                    new OrdersWindow().Show();
                    Close();
                }
            }
        }

        private void onRegistrateButtonClick(object sender, RoutedEventArgs e)
        {
            new RegistrateWindow().ShowDialog();
        }
    }
}